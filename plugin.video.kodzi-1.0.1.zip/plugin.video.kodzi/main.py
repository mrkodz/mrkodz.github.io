import sys
from urlparse import parse_qsl
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import re, requests, zipfile, StringIO
import sqlite3
import os
import HTMLParser
import shutil
from definitions import *
		
_url = sys.argv[0]
_handle = int(sys.argv[1])
addon = xbmcaddon.Addon('plugin.video.kodzi')
title = addon.getAddonInfo('name')
icon = addon.getAddonInfo('icon')
des = xbmc.translatePath(homes)
s = requests.Session()
s.headers.update({'User-Agent': h})


def busy_dialog():
	kvers = xbmc.getInfoLabel("System.BuildVersion")
	if kvers.startswith('18'):
		return 'busydialognocancel'
	else:
		return 'busydialog'

		
def web_str(url):
	url2 = url.lower()
	if url2.startswith('http'):
		return url
	else:
		url = 'http://' + url
		return url

		
def check_rep():
	if xbmc.getCondVisibility('System.HasAddon(%s)' % repos) == 0:
		k = ins_add(repol)
		if xbmc.getCondVisibility('System.HasAddon(%s)' % repos) == 1:
			return 1
	else:
		return 1

	
def kodi_time():
	kodi_date = xbmc.getInfoLabel('System.Date(yyyy-mm-dd)').strip()
	kodi_time = xbmc.getInfoLabel('System.Time(hh:mm:ss)').strip()
	k = kodi_date + ' ' + kodi_time
	return k

	
def sub_link():
	getda = s.get(base_link + subred_link)
	comli = re.compile(redth, re.I)
	redlink = comli.search(getda.text, re.MULTILINE)
	if redlink:
		newna = re.compile(redpo, re.I).findall(redlink.group())[0]
		newna = newna.split('comments/')[-1].split('/')[0]
		newli = base_link + get_link % (newna, newna)
		newli = s.get(newli).json()
		newda = newli[1]['data']['children']
		listing = []
		for theda in newda:
			r = re.compile(redpoa, re.DOTALL).findall(str(theda))
			if r:
				for title,link in r:
					# Minimize updated comments problem, change later
					if title and link:
						r = [(title, link)]
						listing += r			
	return listing


def search_str(link):
	if link.startswith('2'):
		return kodi_exec('all')
	elif link.startswith('3'):
		return xbmc.executebuiltin('ActivateWindow(SystemSettings)')
	else:
		d = dia_lo(6, '1', '2')
		if d.startswith('gc:'):
			d = d.replace('gc:','')
			d = dh % (d)
			return ins_add(d)
		elif d.startswith('gt:'):
			d = d.replace('gt:','')
			dna = '/'.join(d.split('/')[0:2])
			nd = d.replace(dna, '')
			kd = kdh % (dna, nd)
			return ins_add(kd)
		elif not d:
			return
		else:
			return ins_add(d)
		

def main_land():
	k = check_rep()
	if k:
		listing = []
		t3 = s.get(page)
		t3 = re.compile(reg1, re.I).findall(t3.content)
		for link,title in t3:
			li = xbmcgui.ListItem(label=title.split('-')[-1], thumbnailImage=icon)
			if link == '1':
				is_folder = False
				url = '{0}?action=search&search={1}'.format(_url, title)
			elif link == '2':
				is_folder = True
				url = '{0}?action=enter&page={1}'.format(_url, link)
			listing.append((url, li, is_folder))
		xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
		xbmcplugin.endOfDirectory(_handle)
	else:
		return

	
def mainlan(link):
	if link == '2':
		sub_cate()

		
def sub_cate():
	listing = []
	k2 = sub_link()
	for title,link in k2:
		title = HTMLParser.HTMLParser().unescape(title)
		li = xbmcgui.ListItem(label=title, thumbnailImage=icon, path=link)
		is_folder = False
		url = '{0}?action=listing&category={1}'.format(_url, link)
		listing.append((url, li, is_folder))
	xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
	xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
	xbmcplugin.endOfDirectory(_handle)


def ins_add(link):	
	xbmc.executebuiltin("ActivateWindow("+busy_dialog()+")")
	link2 = link.lower()
	if link2.startswith('http') and link2.endswith('.zip'):
		# [5] Temproray [21]
		askq = dia_lo(4, link, link)
		if askq == 1:
			repo_check(link)
		else:
			return xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
	elif 'github' in link2:
		git_url(link)
	else:
		if link2.startswith('http'):
			find_zip(link)
		else:
			link2 = 'http://' + link
			if link2.endswith('.zip'):
				repo_check(link2)
			else:
				find_zip(link2)

		
def git_url(url):
	k = url
	try:
		if 'github.io' in k:
			findurl = tryfind_zip(k)
			if not findurl:
				return
			elif findurl.startswith('http'):
				return repo_check(findurl)
			elif 'blob/master' in url:
				url = maingit + findurl
				url = url.replace('blob', 'raw')
				return repo_check(url)
			else:
				url = url + '/' + findurl
				return repo_check(url)
		else:
			findurl = tryfind_zip(k)
			if not findurl:
				return		
			if findurl.startswith('http') and findurl.endswith('.zip'):
				return repo_check(findurl)
			elif findurl.endswith('.zip'):
				newlink = maingit + findurl
				newlink = newlink.replace('blob', 'raw')
				return repo_check(newlink)
			else:
				newlink = k + gitend			
				return repo_check(newlink)
	except:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		print("Unexpected ERROR in KODZ INSTALLER: ", exc_type, exc_tb.tb_lineno)
		dia_lo(0, '', url)

	
def tryfind_zip(url):
	url = web_str(url)
	findurl = s.get(url, timeout=5).text
	findurl = re.compile(fzreg, re.I).findall(findurl)
	ret = xbmcgui.Dialog().select(sra, findurl)
	if ret < 0:
		return xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
	findurl = findurl[ret]
	return findurl


def find_zip(url):
	try:
		url = web_str(url)
		findzurl = s.get(url, timeout=5).text
		findzurl = re.compile(fzreg, re.I).findall(findzurl)
		if findzurl:
			ret = xbmcgui.Dialog().select(sra, findzurl)
			if ret < 0:
				return xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
			findzurl = findzurl[ret]
			if findzurl.startswith('http') and findzurl.endswith('.zip'):
				return repo_check(findzurl)
			else:
				try:
					findzurln = 'http://' + findzurl
					findzurlre = s.get(findzurln, timeout=5)
					if findzurlre.ok:
						return repo_check(findzurln)
				except:
					try:
						if findzurl.startswith('/'):
							findzurl = url + findzurl
						else:
							findzurl = url + '/' + findzurl
						findzurlre = s.get(findzurl, timeout=5)
						if findzurlre.ok:
							return repo_check(findzurl)
					except:
						exc_type, exc_obj, exc_tb = sys.exc_info()
						print("Unexpected ERROR in KODZ INSTALLER: ", exc_type, exc_tb.tb_lineno)
						dia_lo(1, k4, url)
		else:
			dia_lo(7, '', nra)
	except:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		k = str(exc_type).split(".")[-1].split("'")[0]
		dia_lo(1, k, url)


def dia_lo(k, header, url):
	text11 = text1 % (header, url)
	text41 = text4 % (header)
	dialog = xbmcgui.Dialog()
	if k == 0:
		xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
		return xbmcgui.Dialog().ok(title, text)
	elif k == 1:
		xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
		return xbmcgui.Dialog().ok(title, text11)
	elif k == 3:
		xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
		return xbmcgui.Dialog().ok(title, url)
	elif k == 4:
		return xbmcgui.Dialog().yesno(title + ' Install', text41)
	elif k == 5:
		return xbmcgui.Dialog().yesno(title, header)
	elif k == 6:
		return xbmcgui.Dialog().input('Enter URL', type=xbmcgui.INPUT_ALPHANUM)
	elif k == 7:
		xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
		return xbmcgui.Dialog().notification(title, url, xbmcgui.NOTIFICATION_ERROR, 5000)
	elif k == 8:
		xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
		return xbmcgui.Dialog().notification(title, url, icon, 5000)

		
def repo_check(zurl):
	zurl = web_str(zurl)
	try:
		add27 = xbmc.translatePath(addo2)
		r = s.get(zurl, stream=True)
		if r.ok:
			z = zipfile.ZipFile(StringIO.StringIO(r.content), 'r')
			lh = z.namelist()
			for kt in lh:
				if addxml in kt:
					repname = kt
			k = z.read(repname, 'r')
			repname = re.compile(regrc, re.I).findall(k)[0]
			if xbmc.getCondVisibility('System.HasAddon(%s)' % repname) == 0:
				askq = 1 
				if askq == 1:
					conn = sqlite3.connect(add27)
					c = conn.cursor()
					for row in c.execute('SELECT * FROM installed ORDER BY id DESC LIMIT 1'):
						try:
							lastid = row[0]
							newid = lastid + 1
							createrow = [(newid, repname, 1, kodi_time(), None, None, '')]
							c.executemany('INSERT INTO installed VALUES (?,?,?,?,?,?,?)', createrow)
							conn.commit()
							conn.close()
							z.extractall(des)
							if 'github' in zurl:
								getaddir = os.listdir(des)
								for mast in getaddir:
									if repname and '-master' in mast:
										k21 = mast.replace('-master','')
										k11 = os.path.join(des, mast)
										k13 = os.path.join(des, k21)
										os.rename(k11, k13)
							xbmc.executebuiltin('UpdateLocalAddons')
							xbmc.sleep(200)
							if xbmc.getCondVisibility('System.HasAddon(%s)' % repname) == 1:
								if repos in repname:
									return xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
								dia_lo(8, '', '%s is Installed' % (repname))
								askq = dia_lo(5, issi % (repname), zurl)
								if askq == 1:
									return kodi_exec(repname)
								else:
									return
							else:
								z = des + repname
								shutil.rmtree(z)
								return dia_lo(7, 'FAILED', faili)
						except:
							askq = dia_lo(5, text5, zurl)
							exc_type, exc_obj, exc_tb = sys.exc_info()
							print("Unexpected ERROR in KODZ INSTALLER: ", exc_type, exc_tb.tb_lineno)
							if askq == 1:
								return kodi_exec('all')
							else:
								xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
				else:
					return xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
			else:
				askq = dia_lo(5, aains, '')
				if askq == 1:
					return kodi_exec(repname)
				else:
					return xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
		else:
			conn.close()
			return dia_lo(3, k4, zfail)
	except:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		print("Unexpected ERROR in KODZ INSTALLER: ", exc_type, exc_tb.tb_lineno)
		return dia_lo(3, k4, zinsf)

	
def kodi_exec(name):	
	xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
	if 'repository' in name:
		return xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://'+name+'/)')
	elif 'plugin.video' in name:
		return xbmc.executebuiltin('ActivateWindow(Videos,plugin://'+name+'/)')
	elif 'script.' in name:
		return xbmc.executebuiltin('ActivateWindow(AddonBrowser,plugin://'+name+'/)')
	else:
		return xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://user/all)')


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if 'content_type' in params:
        main_land()
    elif params:
        if params['action'] == 'enter':
            mainlan(params['page'])
        elif params['action'] == 'listing':
            ins_add(params['category'])
        elif params['action'] == 'search':
            search_str(params['search'])
    else:
        main_land()
		

if __name__ == '__main__':
    router(sys.argv[2][1:])
