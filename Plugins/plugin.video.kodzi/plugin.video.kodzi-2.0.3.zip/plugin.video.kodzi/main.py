import sys
from urlparse import parse_qsl
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import re, requests, zipfile, StringIO
import sqlite3
import os
import HTMLParser, pickle
import shutil
from definitions import *
		
_url = sys.argv[0]
_handle = int(sys.argv[1])
addon = xbmcaddon.Addon('plugin.video.kodzi')
title = addon.getAddonInfo('name')
icon = addon.getAddonInfo('icon')
des = xbmc.translatePath(homes)
hist = xbmc.translatePath(homeda)
s = requests.Session()
s.headers.update({'User-Agent': h})


def busy_dialog():
	kvers = xbmc.getInfoLabel("System.BuildVersion")
	if kvers.startswith('18'):
		return 'busydialognocancel'
	else:
		return 'busydialog'

		
def web_str(url):
	url2 = url.lower()
	if url2.startswith('http'):
		return url
	else:
		url = 'http://' + url
		return url

	
def kodi_time():
	kodi_date = xbmc.getInfoLabel('System.Date(yyyy-mm-dd)').strip()
	kodi_time = xbmc.getInfoLabel('System.Time(hh:mm:ss)').strip()
	k = kodi_date + ' ' + kodi_time
	return k

	
def sub_link():
	getda = s.get(base_link + subred_link)
	comli = re.compile(redth, re.I)
	redlink = comli.search(getda.text, re.MULTILINE)
	if redlink:
		newna = re.compile(redpo, re.I).findall(redlink.group())[0]
		newna = newna.split('comments/')[-1].split('/')[0]
		newli = base_link + get_link % (newna, newna)
		newli = s.get(newli).json()
		newda = newli[1]['data']['children']
		listing = []
		for theda in newda:
			r = re.compile(redpoa, re.DOTALL).findall(str(theda))
			if r:
				for title,link in r:
					# Minimize updated comments problem, change later
					if title and link:
						r = [(title, link)]
						listing += r			
	return listing


def search_str(link):
	if link.startswith('2'):
		return kodi_exec('all')
	elif link.startswith('3'):
		return xbmc.executebuiltin('ActivateWindow(SystemSettings)')
	else:
		d = dia_lo(6, '1', '2')
		if d.startswith('gc:'):
			d = d.replace('gc:','')
			d = dh % (d)
			return ins_add(d)
		elif d.startswith('gt:'):
			d = d.replace('gt:','')
			dna = '/'.join(d.split('/')[0:2])
			nd = d.replace(dna, '')
			kd = kdh % (dna, nd)
			return ins_add(kd)
		elif not d:
			return
		else:
			val = [d, d]
			wri_his(val, 1)
			return ins_add(d)
		

def main_land():
	k = get_replist()
	if k:
		listing = []
		t3 = s.get(page)
		t3 = re.compile(reg1, re.I).findall(t3.content)
		for link,title in t3:
			li = xbmcgui.ListItem(label=title.split('-')[-1], thumbnailImage=icon)
			if link == '1':
				is_folder = False
				url = '{0}?action=search&search={1}'.format(_url, title)
			elif link == '2':
				is_folder = True
				if title.startswith('5'):
					li.setLabel('[COLOR blue]%s[/COLOR]' % (title.split('-')[-1]))
				url = '{0}?action=enter&page={1}'.format(_url, title)
			elif link == '3':
				li.setLabel('[COLOR FF00C936]%s[/COLOR]' % (title.split('-')[-1]))
				is_folder = False
				url = '{0}?action=search&search={1}'.format(_url, title)
			listing.append((url, li, is_folder))
		xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
		xbmcplugin.endOfDirectory(_handle)
	else:
		return

	
def mainlan(link):
	if link.startswith('3'):
		d = dia_lo(6, '1', '2')
		if d:
			return onli_web(d)
		else:
			return
	elif link.startswith('2'):
		numb = link.split('-')[0][-1]
		return sub_cate(numb)
	elif link.startswith('1'):
		d = dia_lo(6, '1', '2')
		if d:
			val = ['Lists', d]
			wri_his(val, 2)
			return lis_list(d)
		else:
			return
	elif link.startswith('4'):
		return onli_web('4')
	elif link.startswith('5'):
		return hist_ory()
	else:
		return new_github(link)

	
def hist_ory():
	listing = []
	li2 = xbmcgui.ListItem(label=clearh, thumbnailImage=icon)
	li2.setLabel('[COLOR lime]%s[/COLOR]' % (clearh))
	is_folder2 = False
	url2 = '{0}?action=history&clear={1}'.format(_url, 'kodzidelete')
	listing.append((url2, li2, is_folder2))
	t3 = wri_his('','')
	if t3:
		for title,link,ch in t3:
			if ch == 2:
				title = 'List: %s' % link
			if ch >= 3:
				title = 'Github: %s' % title
			if ch == 1:
				colo = 'blue'
				is_folder = False
				url = '{0}?action=listing&category={1}'.format(_url, link)
			else:
				colo = 'white'
				link = '-'.join([str(ch),link])
				is_folder = True
				url = '{0}?action=hist&create={1}'.format(_url, link)
			li = xbmcgui.ListItem(label=title, thumbnailImage=icon)
			li.setLabel('[COLOR %s]%s[/COLOR]' % (colo, title))
			listing.append((url, li, is_folder))
	xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
	xbmcplugin.endOfDirectory(_handle)
		

def wri_his(val, ch):
	homed = xbmc.translatePath(homeda)
	listing = []
	kii = os.path.join(os.path.dirname(homed),'history')
	if not os.path.exists(homed):
		os.makedirs(homed)
	if val:
		if os.path.exists(kii):
			with open(kii,'rb') as rfp:
				listing = pickle.load(rfp)
		if any(val[0] in s for s in listing):
			return
		elif val == 'kodzidelete':
			try:
				if os.path.exists(homed):
					shutil.rmtree(homed)
					xbmc.executebuiltin("Container.Refresh")
					return his_tory()
			except:
				print(errmd, homed)
		else:
			val.append(ch)
			listing.append(val)
			with open(kii,'wb') as wfp:
				pickle.dump(listing, wfp)
	else:
		if os.path.exists(kii):
			with open(kii,'rb') as rfp:
				listing = pickle.load(rfp)
				return listing

			
def get_replist():
	if xbmc.getCondVisibility('System.HasAddon(%s)' % repos) == 0:
		k = ins_add(repol)
		if xbmc.getCondVisibility('System.HasAddon(%s)' % repos) == 1:
			return 1
	else:
		return 1
	
	
def new_github(link):
	if link == 'kodzigitse':
		d = dia_lo(6, '1', '2')
		if d:
			url = ngitse % (d)
			val = [d, d]
			wri_his(val, 3)
			return sub_cate(url)
		else:
			return
	if link == 'kodzigitus':
		d = dia_lo(6, '1', '2')
		if d:
			url = ''.join([ngitse, 'Users']) % (d)
			val = [d, d]
			wri_his(val, 4)
			return sub_cate(url)
		else:
			return
	else:
		return

	
def onli_web(link):
	listing = []
	if link.startswith('4'):
		link = kodiappss + 'addons-chart'
		t3 = s.get(link)
		t3 = re.compile(kapreg, re.I).findall(t3.content)
		for link,icon in t3:
			title = icon.split('/')[-1].split('.')[0].replace('-', ' ')
			li = xbmcgui.ListItem(label=title, thumbnailImage=kodiappss+icon)
			is_folder = False
			url = '{0}?action=apps&kodiapps={1}'.format(_url, kodiappss+link)
			listing.append((url, li, is_folder))
	else:
		link = koditips + '?s=install+' + link
		link = link.replace(' ','+')
		t3 = s.get(link)
		t3 = re.compile(regmti, re.I).findall(t3.content)
		for link,icon,title in t3:
			title = HTMLParser.HTMLParser().unescape(title)
			li = xbmcgui.ListItem(label=title, thumbnailImage=koditips+icon)
			is_folder = False
			url = '{0}?action=tips&koditips={1}'.format(_url, link)
			listing.append((url, li, is_folder))	
	xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
	xbmcplugin.endOfDirectory(_handle)

	
def cre_his(link):
	nlink = link.split('-', 1)[1]
	if link.startswith('2'):
		return lis_list(nlink)
	elif link.startswith('3'):
		link = ngitse % (nlink)
		return sub_cate(link)
	elif link.startswith('4'):
		link = ''.join([ngitse, 'Users']) % (nlink)
		return sub_cate(link)
	
	
def kodaps_link(link):
	try:
		xbmc.executebuiltin("ActivateWindow("+busy_dialog()+")")
		t3 = s.get(link).content
		t3 = re.compile(kaplreg, re.I).findall(t3)[0]
		xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
		return ins_add(t3)
	except:
		xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
		return dia_lo(7, '', nra)
	
	
def tips_link(url):
	try:
		url = koditips + url
		url = s.get(url)
		url = re.compile(regtip, re.I).findall(url.content)[0]
		return ins_add(url)
	except:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		print("Unexpected ERROR in KODZ INSTALLER: ", exc_type, exc_tb.tb_lineno)
		return dia_lo(3, '', nra)
		

def lis_list(link):
	listing = []
	link = web_str(link)
	t3 = s.get(link)
	t3 = re.compile(reglis, re.I).findall(t3.content)
	for title,link in t3:
		title = HTMLParser.HTMLParser().unescape(title)
		li = xbmcgui.ListItem(label=title, thumbnailImage=icon)
		is_folder = False
		url = '{0}?action=listing&category={1}'.format(_url, link)
		listing.append((url, li, is_folder))
	xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
	xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
	xbmcplugin.endOfDirectory(_handle)
	
	
def git_list(link):
	listing = []
	s.headers.update({'User-Agent': hi})
	k2 = s.get(link).content
	if link.endswith('tab=repositories'):
		k2 = re.compile(grepre, re.I).findall(k2)
	else:
		k2 = re.compile(gelsre, re.I).findall(k2)
	for link,title in k2:
		if '/' and '"' not in title:
			li = xbmcgui.ListItem(label=link)
			link = ''.join([maingiti, '?files=1']) % (link)
			is_folder = True
			url = '{0}?action=git&list={1}'.format(_url, link)
		elif title.endswith('"') and not link.endswith('.zip'):
			li = xbmcgui.ListItem(label=link.split('/')[-1])
			link = maingiti % (link)
			if 'directory' in title:
				is_folder = True
			else:
				is_folder = False
			url = '{0}?action=git&list={1}'.format(_url, link)
		elif link.endswith('.zip'):
			li = xbmcgui.ListItem(label=link.split('/')[-1], thumbnailImage=icon)
			link = maingiti % (link)
			link = link.replace('/blob/','/raw/')
			is_folder = False
			url = '{0}?action=listing&category={1}'.format(_url, link)
			#TO DO, FOR NON ZIPS
		else:
			is_folder = False
			url = '{0}?action=listing&category={1}'.format(_url, link)
		listing.append((url, li, is_folder))
	xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
	xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
	xbmcplugin.endOfDirectory(_handle)
	
	
def sub_cate(link):
	listing = []
	if link == '1':
		k2 = sub_link()
	elif link == '2':
		k2 = [(segit, segitn % ("se")), 
			  (segit + " Username", segitn % ("us"))]
	else:
		s.headers.update({'User-Agent': hi})
		k2 = s.get(link).content
		k2 = re.compile(gmaire, re.I).findall(k2)
	for title,link in k2:
		title = HTMLParser.HTMLParser().unescape(title)
		li = xbmcgui.ListItem(label=title, thumbnailImage=icon)
		if link.startswith('2'):
			link = link.split('-')[-1]
			is_folder = True
			url = '{0}?action=enter&page={1}'.format(_url, link)
		elif link.startswith('http'):
			is_folder = False
			url = '{0}?action=listing&category={1}'.format(_url, link)
		else:
			is_folder = True
			link = title
			if '/' in link:
				link = link.split('/')[0]
			link = ''.join([maingiti, '?tab=repositories']) % (link)
			url = '{0}?action=git&list={1}'.format(_url, link)
		listing.append((url, li, is_folder))
	xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
	xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
	xbmcplugin.endOfDirectory(_handle)


def ins_add(link):	
	xbmc.executebuiltin("ActivateWindow("+busy_dialog()+")")
	link2 = link.lower()
	if link2.startswith('http') and link2.endswith('.zip'):
		# [5] Temproray [21]
		askq = dia_lo(4, link, link)
		if askq == 1:
			repo_check(link)
		else:
			return xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
	elif 'github' in link2:
		git_url(link)
	else:
		if link2.startswith('http'):
			find_zip(link)
		else:
			link2 = 'http://' + link
			if link2.endswith('.zip'):
				repo_check(link2)
			else:
				find_zip(link2)

		
def git_url(url):
	k = url
	try:
		if 'github.io' in k:
			findurl = tryfind_zip(k)
			if not findurl:
				return
			elif findurl.startswith('http'):
				return repo_check(findurl)
			elif 'blob/master' in url:
				url = maingit + findurl
				url = url.replace('blob', 'raw')
				return repo_check(url)
			else:
				url = url + '/' + findurl
				return repo_check(url)
		else:
			findurl = tryfind_zip(k)
			if not findurl:
				return		
			if findurl.startswith('http') and findurl.endswith('.zip'):
				return repo_check(findurl)
			elif findurl.endswith('.zip'):
				newlink = maingit + findurl
				newlink = newlink.replace('blob', 'raw')
				return repo_check(newlink)
			else:
				newlink = k + gitend			
				return repo_check(newlink)
	except:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		print("Unexpected ERROR in KODZ INSTALLER: ", exc_type, exc_tb.tb_lineno)
		dia_lo(0, '', url)

	
def tryfind_zip(url):
	url = web_str(url)
	findurl = s.get(url, timeout=5).text
	findurl = re.compile(fzreg, re.I).findall(findurl)
	ret = xbmcgui.Dialog().select(sra, findurl)
	if ret < 0:
		return xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
	findurl = findurl[ret]
	return findurl


def find_zip(url):
	try:
		url = web_str(url)
		findzurl1 = s.get(url, timeout=5).content
		findzurl = re.compile(fzreg, re.I).findall(findzurl1)
		if findzurl:
			ret = xbmcgui.Dialog().select(sra, findzurl)
			if ret < 0:
				return xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
			findzurl = findzurl[ret]
			if findzurl.startswith('http') and findzurl.endswith('.zip'):
				return repo_check(findzurl)
			else:
				try:
					findzurln = 'http://' + findzurl
					findzurlre = s.get(findzurln, timeout=5)
					if findzurlre.ok:
						return repo_check(findzurln)
				except:
					try:
						if not findzurl.startswith('/'):
							findzurl = '/' + findzurl
						findzurln = url + findzurl
						findzurlre = s.get(findzurln, timeout=5)
						if findzurlre.ok:
							return repo_check(findzurln)
						else:
							url = '/'.join(url.split('/')[0:3])
							findzurln = url + findzurl
							findzurlre = s.get(findzurln, timeout=5)
							if findzurlre.ok:
								return repo_check(findzurln)
							else:
								return
							
					except:
						exc_type, exc_obj, exc_tb = sys.exc_info()
						print("Unexpected ERROR in KODZ INSTALLER: ", exc_type, exc_tb.tb_lineno)
						dia_lo(1, k4, url)
		else:
			try:
				if zipfile.is_zipfile(StringIO.StringIO(findzurl1)):
					return repo_check(url)
			except:
				dia_lo(7, '', nra)
	except:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		k = str(exc_type).split(".")[-1].split("'")[0]
		dia_lo(1, k, url)


def dia_lo(k, header, url):
	text11 = text1 % (header, url)
	text41 = text4 % (header)
	dialog = xbmcgui.Dialog()
	if k == 0:
		xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
		return xbmcgui.Dialog().ok(title, text)
	elif k == 1:
		xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
		return xbmcgui.Dialog().ok(title, text11)
	elif k == 3:
		xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
		return xbmcgui.Dialog().ok(title, url)
	elif k == 4:
		return xbmcgui.Dialog().yesno(title + ' Install', text41)
	elif k == 5:
		return xbmcgui.Dialog().yesno(title, header)
	elif k == 6:
		return xbmcgui.Dialog().input('Enter URL', type=xbmcgui.INPUT_ALPHANUM)
	elif k == 7:
		xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
		return xbmcgui.Dialog().notification(title, url, xbmcgui.NOTIFICATION_ERROR, 5000)
	elif k == 8:
		xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
		return xbmcgui.Dialog().notification(title, url, icon, 5000)

		
def repo_check(zurl):
	zurl = web_str(zurl)
	try:
		add27 = xbmc.translatePath(addo2)
		r = s.get(zurl, stream=True)
		if r.ok:
			z = zipfile.ZipFile(StringIO.StringIO(r.content), 'r')
			lh = z.namelist()
			for kt in lh:
				if addxml in kt:
					repname = kt
			k = z.read(repname, 'r')
			repname = re.compile(regrc, re.I).findall(k)[0]
			if xbmc.getCondVisibility('System.HasAddon(%s)' % repname) == 0:
				askq = 1 
				if askq == 1:
					conn = sqlite3.connect(add27)
					c = conn.cursor()
					for row in c.execute('SELECT * FROM installed ORDER BY id DESC LIMIT 1'):
						try:
							lastid = row[0]
							newid = lastid + 1
							createrow = [(newid, repname, 1, kodi_time(), None, None, '')]
							c.executemany('INSERT INTO installed VALUES (?,?,?,?,?,?,?)', createrow)
							conn.commit()
							conn.close()
							z.extractall(des)
							if 'github' in zurl:
								getaddir = os.listdir(des)
								for mast in getaddir:
									if repname and '-master' in mast:
										k21 = mast.replace('-master','')
										k11 = os.path.join(des, mast)
										k13 = os.path.join(des, k21)
										os.rename(k11, k13)
							xbmc.executebuiltin('UpdateLocalAddons')
							xbmc.sleep(200)
							if xbmc.getCondVisibility('System.HasAddon(%s)' % repname) == 1:
								if repos in repname:
									return xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
								dia_lo(8, '', '%s is Installed' % (repname))
								askq = dia_lo(5, issi % (repname), zurl)
								if askq == 1:
									return kodi_exec(repname)
								else:
									return
							else:
								z = des + repname
								shutil.rmtree(z)
								return dia_lo(7, 'FAILED', faili)
						except:
							askq = dia_lo(5, text5, zurl)
							exc_type, exc_obj, exc_tb = sys.exc_info()
							print("Unexpected ERROR in KODZ INSTALLER: ", exc_type, exc_tb.tb_lineno)
							if askq == 1:
								return kodi_exec('all')
							else:
								xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
				else:
					return xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
			else:
				askq = dia_lo(5, aains, '')
				if askq == 1:
					return kodi_exec(repname)
				else:
					return xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
		else:
			conn.close()
			return dia_lo(3, k4, zfail)
	except:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		print("Unexpected ERROR in KODZ INSTALLER: ", exc_type, exc_tb.tb_lineno)
		return dia_lo(3, k4, zinsf)

	
def kodi_exec(name):	
	xbmc.executebuiltin("Dialog.Close("+busy_dialog()+")")
	if 'repository' in name:
		return xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://'+name+'/)')
	elif 'plugin.video' in name:
		return xbmc.executebuiltin('ActivateWindow(Videos,plugin://'+name+'/)')
	elif 'script.' in name:
		return xbmc.executebuiltin('ActivateWindow(AddonBrowser,plugin://'+name+'/)')
	else:
		return xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://user/all)')


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if 'content_type' in params:
        main_land()
    elif params:
        if params['action'] == 'enter':
            mainlan(params['page'])
        elif params['action'] == 'listing':
            ins_add(params['category'])
        elif params['action'] == 'search':
            search_str(params['search'])
        elif params['action'] == 'tips':
            tips_link(params['koditips'])
        elif params['action'] == 'apps':
            kodaps_link(params['kodiapps'])
        elif params['action'] == 'git':
            git_list(params['list'])
        elif params['action'] == 'history':
            wri_his(params['clear'], '')
        elif params['action'] == 'hist':
            cre_his(params['create'])
    else:
        main_land()
		

if __name__ == '__main__':
    router(sys.argv[2][1:])
